======================================================================
   Databricks Migration AI Studio - Standalone Local Agent
======================================================================

Quick Start (Windows):
----------------------
1. Open 'agent.env' in Notepad and enter your CONNECTOR_TOKEN from Studio UI.
2. Double-click 'migration-agent.exe' (or 'run_agent.bat').
3. The agent will connect outward over HTTPS to Migration AI Studio.
   No ports need to be opened on your firewall!

Switching Databases:
--------------------
To migrate a different database on this server, simply change the
CONNECTOR_DATABASE name in 'agent.env', or run:
  migration-agent.exe --database NewDatabaseName

Python Runner (Alternative):
----------------------------
If not using the .exe, run:
  pip install -r requirements.txt
  python local_connector.py

Corporate proxies, VPN routes and outbound HTTPS policy still require network-team approval/configuration. This bundle does not bypass them.
